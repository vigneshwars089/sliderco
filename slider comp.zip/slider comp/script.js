var app=angular.module('App', ['ngMaterial']);


// var app1=angular.module('main'[])
// app1.config(function($stateProvider,$urlRouterProvider) {


// $('.slider-tick round').bind('click', function() { submit_click(); });
//
// function submit_click()
// {
//     alert ("Hai");
// }
// $('.newslider').slider().on('change', function(event) {
console.log($('#ex19').slider());
$('#ex19').slider().on('change', function(event) {
  document.getElementById("newcheck2").style.display="none";
  document.getElementById("newcheck3").style.display="none";
  document.getElementById("newcheck4").style.display="none";
  document.getElementById("newcheck5").style.display="none";

   var newVal = $('#ex19').data('slider').getValue();
   if (newVal<=3) {
     document.getElementById("input1").checked = false;
     document.getElementById("input2").checked = false;
     document.getElementById("newcheck").style.display="";
   }
   else {
     document.getElementById("newcheck").style.display="none";
   }
});
$('#ex20').slider().on('change', function(event) {
  document.getElementById("newcheck").style.display="none";
  document.getElementById("newcheck3").style.display="none";
  document.getElementById("newcheck4").style.display="none";
  document.getElementById("newcheck5").style.display="none";
   var newVal = $('#ex20').data('slider').getValue();
   if (newVal<=3) {
     document.getElementById("input3").checked = false;
     document.getElementById("input4").checked = false;
     document.getElementById("newcheck2").style.display="";
   }
   else {
     document.getElementById("newcheck2").style.display="none";
   }
});
$('#ex21').slider().on('change', function(event) {
  document.getElementById("newcheck").style.display="none";
  document.getElementById("newcheck2").style.display="none";
  document.getElementById("newcheck4").style.display="none";
  document.getElementById("newcheck5").style.display="none";
   var newVal = $('#ex21').data('slider').getValue();
   if (newVal<=3) {
     document.getElementById("input5").checked = false;
     document.getElementById("input6").checked = false;
     document.getElementById("newcheck3").style.display="";
   }
   else {
     document.getElementById("newcheck3").style.display="none";
   }
});
$('#ex22').slider().on('change', function(event) {
  document.getElementById("newcheck").style.display="none";
  document.getElementById("newcheck2").style.display="none";
  document.getElementById("newcheck3").style.display="none";
  document.getElementById("newcheck5").style.display="none";
   var newVal = $('#ex22').data('slider').getValue();
   if (newVal<=3) {
     document.getElementById("input7").checked = false;
     document.getElementById("input8").checked = false;
     document.getElementById("newcheck4").style.display="";
   }
   else {
     document.getElementById("newcheck4").style.display="none";
   }
});
$('#ex23').slider().on('change', function(event) {
  document.getElementById("newcheck").style.display="none";
  document.getElementById("newcheck2").style.display="none";
  document.getElementById("newcheck3").style.display="none";
  document.getElementById("newcheck4").style.display="none";
   var newVal = $('#ex23').data('slider').getValue();
   if (newVal<=3) {
     document.getElementById("input9").checked = false;
     document.getElementById("input10").checked = false;
     document.getElementById("newcheck5").style.display="";

   }
   else {
     document.getElementById("newcheck5").style.display="none";
   }
});
var myList = [
  { "Feedback": "Data Visibility of the App?", "que":["Wrong product is selected","Delay in delivery"]},
  { "Feedback": "User Experience of the App?", "que":["Wrong product is selected","Delay in delivery"]},
  { "Feedback": "Usage of the App?", "que":["Wrong product is selected","Delay in delivery"]},
  { "Feedback": "Data Quality of the App?", "que":["Wrong product is selected","Delay in delivery"]},
  { "Feedback": "Performance of the App?", "que":["Wrong product is selected","Delay in delivery"]}
];
//  console.log(newVal);
// var a = event.value.newValue;
// var b = event.value.oldValue;
//
// var changed = !($.inArray(a[0], b) !== -1 &&
//                 $.inArray(a[1], b) !== -1 &&
//                 $.inArray(b[0], a) !== -1 &&
//                 $.inArray(b[1], a) !== -1 &&
//                 a.length === b.length);

// if(changed ) {
// alert("change");
//     console.log('changed');
// }

// document.getElementsByClassName("slider-tick round").addEventListener("click", sample);
function sample(){
  console.log("hai");
  // classname=document.querySelectorAll(".slider-handle");
  // console.log(document.querySelectorAll(".slider-handle"));
//   var x = document.querySelectorAll(".slider-handle");
// x[0].style.backgroundColor = "red";

  //  var check = document.createElement("input");
  //  check.type="checkbox";
  // for (var i = 0; i < classname.length; i++) {
  //   console.log("haui");
  //   console.log(classname[i]);
  //   classname[i].innerHTML="";
  // }
}
app.controller('demoController', function($scope,$http) {
  $scope.myList = [
    { "Feedback": "Data Visibility of the App?", "que":["Wrong product is selected","Delay in delivery"]},
    { "Feedback": "User Experience of the App?", "que":["Wrong product is selected","Delay in delivery"]},
    { "Feedback": "Usage of the App?", "que":["Wrong product is selected","Delay in delivery"]},
    { "Feedback": "Data Quality of the App?", "que":["Wrong product is selected","Delay in delivery"]},
    { "Feedback": "Performance of the App?", "que":["Wrong product is selected","Delay in delivery"]}
  ];

	// $http.get('./sample.json').success(function(data) {
	// 	// $scope.tooltipFunc = function(branch) {
	// 	// 	return branch.name;
	// 	// };
	// 			// $scope.myStyle="width:150px;height:100px;"
	// 		 $scope.vennData = data.sample;
	// 	 });
	// 	 	$scope.change=function(){
	// 			document.getElementById("change").innerHTML=""
	// 			$http.get('./sam.json').success(function(data) {
	// 				// $scope.tooltipFunc = function(branch) {
	// 				// 	return branch.name;
	// 				// };
	// 						// $scope.myStyle="width:150px;height:100px;"
	// 					 $scope.vennData = data.sample;
	// 				 });
	// 		}
	// console.log("SDLbnkasdkb");
	// $scope.myStyle="width:'200px';background:red";
	// $scope.vennData = [
	// 	{sets: ['Head Count'], size: 70},
	// 	{sets: ['Billable Allocation'], size: 20},
	// 	{sets: ['SGA'], size: 10},
	// 	{sets: ['Non-Billable Allocation'], size: 10},
	// 	 {sets: ['Head Count','Billable Allocation'], size: 20},
	// 	 {sets: ['Head Count','SGA'], size: 30},
	// 	 {sets: ['Head Count','Non-Billable Allocation'], size: 20},
	// 	//  {sets: ['Head Count','Billable Allocation', 'SGA'], size: 1},
	// ];

});
// });
